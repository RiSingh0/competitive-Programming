t=int(input())
for _ in range(t):
    N, M = map(int,input().split())
    times=M//N
    arr=[times for i in range(N)]
    rem=M%N
    if times%2 == 0:
        for i in range(rem):
            arr[i]+=1
    else:
        for i in range((N-rem),N):
            arr[i]+=1
    print(*arr)
