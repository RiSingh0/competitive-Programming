t=int(input())
for _ in range(t):
    n=int(input())
    arr=[int(x) for x in input().split()]
    xor=0
    for each in arr:
        xor=xor^each
    xor=xor^65
    print(xor)
