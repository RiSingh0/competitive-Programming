from collections import OrderedDict
N, Q = map(int,input().split())
arr=[x for x in input().split()]
arr.reverse()
mp = OrderedDict()
for x in arr:
    mp[x]=1
for q in range(Q):
    q=input().split()
    ty=int(q[0])
    if ty != 3:
        L=q[1]
    if ty == 1:
        if L in mp:
            print(-1)
        else:
            mp[L]=1
    elif ty == 2:
        if L not in mp:
            print(-1)
        else:
            del mp[L]
    else:
        try:
            L=mp.popitem(last=False)
            print(L[0])
        except:
            print(-1)
