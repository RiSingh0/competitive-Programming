import random
f=open("Q3_input2.txt","w+")
word=""
N=100
Q=10000
word+=str(N)
word+=" "
word+=str(Q)
word+="\n"
for i in range(N):
    word+=str(i+1)
    word+=" "
word+="\n"
for i in range(2000):
    word+="1 "
    word+=str(2000+i+1)
    word+="\n"
for i in range(Q-2000):
    ty=random.randint(2, 3)
    word+=str(ty)
    if ty!=3:
        word+=" "
        word+=str(random.randint(1,2000))
    word+="\n"
f.write(word)
f.close()

    
