from collections import OrderedDict
word=""
f=open("Q3_input2.txt","r")
N, Q = map(int,f.readline().split())
arr=[x for x in f.readline().split()]
arr.reverse()
mp = OrderedDict()
for x in arr:
    mp[x]=1
for q in range(Q):
    q=f.readline().split()
    ty=int(q[0])
    if ty != 3:
        L=q[1]
    if ty == 1:
        if L in mp:
            word+="-1\n"
        else:
            mp[L]=1
    elif ty == 2:
        if L not in mp:
            #print(-1)
            word+="-1\n"
        else:
            del mp[L]
    else:
        try:
            L=mp.popitem(last=False)
            word+=L[0]+"\n"
        except:
            word+="-1\n"
f.close()
f=open("Q3_output2.txt","r+")
f.write(word)
f.close()
