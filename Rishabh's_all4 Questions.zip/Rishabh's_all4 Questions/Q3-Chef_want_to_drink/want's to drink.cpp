#include <iostream> 
#include <unordered_map> 
using namespace std; 
class Node
{
    public: 
        int data; 
        Node* next=NULL; 
        Node* prev=NULL;
}; 

int main() 
{ 
    Node* front = NULL; 
    Node* rear = NULL;
	unordered_map<int, Node* > umap;
	int N,Q;
	cin >> N >> Q;
	for(int i=0; i < N; i++)
	{
	    int temp;
	    cin >> temp;
	    Node* fake = new Node();
	    fake->data = temp;
	    if(front == NULL && rear == NULL && umap.size() == 0)
	    {
	        front=fake;
	        rear=fake;
	    }
	    else
	    {
	        rear->next=fake;
	        fake->prev=rear;
	        rear=fake;
	    }
	    umap[temp]=fake;
	}
	for(int i=0; i < Q; i++)
	{
	    int ty;
	    cin >> ty;
	    if(ty == 3)
	    {
	        if(rear == NULL && front == NULL && umap.size() == 0)
	        {
	            cout<<"-1\n";
	        }
	        else
	        {
	            cout<<rear->data<<"\n";
	            umap.erase(rear->data);
	            if(rear == front)
	            {
	                rear = NULL;
	                front = NULL;
	            }
	            else
	            {
	                Node* fake=rear;
	                rear=rear->prev;
	                rear->next=NULL;
	                fake->prev=NULL;
	                 delete fake;
	                 
	            }
	        }
	    }
	    else
	    {
	        int update;
	        cin>>update;
	        if(ty == 1)
	        {
	           
	            if(umap.find(update) == umap.end())
	            {
	                 Node* fake = new Node();
    	             fake->data = update;
    	             umap[update]=fake;
	                if(front == NULL && rear == NULL)
	                {
	                    front=fake;
	                    rear=fake;
	                }
	                else
	                {
    	                 fake->next = front;
    	                 front->prev = fake;
    	                 front = fake;
	                }
	            }
	            else
	            {
	                cout<<"-1\n";
	            }
	        }
	        else
	        {
	             if(umap.find(update) == umap.end())
	             {
	                 cout<<"-1\n";
	             }
	             else
	             {
	                 Node* fake;
	                 fake = umap[update];
	                 if(front == rear)
	                 {
	                      rear = NULL;
	                      front = NULL;
	                 }
	                 else if(fake == front)
	                 {
	                     front=front->next;
	                     fake->next=NULL;
	                     front->prev=NULL;
	                 }
	                 else if(fake == rear)
	                 {
	                     rear=rear->prev;
	                     rear->next=NULL;
	                     fake->prev=NULL;
	                 }
	                 else
	                 {
	                     fake->prev->next = fake->next;
	                     fake->next->prev = fake->prev;
	                     fake->next = NULL;
	                     fake->prev = NULL;
	                 }
	                 delete fake;
	                 umap.erase(update);
	             }
	        }
	    }
	}
}