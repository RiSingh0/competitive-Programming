from sys import setrecursionlimit
setrecursionlimit(10**7)
#Class for graph
class MYGraph:
    def __init__(self,V):
        self.graph=[[] for i in range(V)]
        self.visited=[False for i in range(V)]
        
    def addEdges(self,No):
        for _ in range(No):
            u,v=map(int, input().split())
            self.graph[u-1].append(v-1)
            self.graph[v-1].append(u-1)
                       
    def DFS(self,visit,cnt):
        self.visited[visit]=True
        cnt+=1
        for i in self.graph[visit]:
            if not self.visited[i]:
                cnt=self.DFS(i,cnt)
        return cnt
            
#Taking Input
N, E = map(int, input().split())
g = MYGraph(N)
g.addEdges(E)
kill_the_Code = 0
single = 0
programer_arr = 0

#count both
for i in range(N):
    if not g.visited[i]:
        cnt=g.DFS(i, 0)
        if cnt == 1:
            single+=1
        else:
            programer_arr+=cnt//5
            if cnt%5:
                programer_arr+=1
            kill_the_Code+=1

#if single Atom
programer_arr+=single
print(kill_the_Code,programer_arr)
