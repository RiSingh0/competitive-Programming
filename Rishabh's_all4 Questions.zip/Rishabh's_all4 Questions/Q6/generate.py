import random
words=""
N=random.randint(1, 200000)
Q=random.randint(1, 200000)
words+=str(N)
words+=" "
words+=str(Q)
words+="\n"
for _ in range(N):
    words+=str(random.randint(1, 1000000000))
    words+=" "
words+="\n"
for i in range(2,N+1):
    u=random.randint(1, i-1)
    v=i
    words+=str(u)+" "+str(v)
    words+="\n"
for i in range(Q):
    ty=random.randint(1, 2)
    if ty == 1:
        u=random.randint(1, 1)
        v=random.randint(u, N)
        words+=str(ty)+" "+str(u)+" "+str(v)
        words+="\n"
    else:
        u=random.randint(1, N)
        v=random.randint(1, 1000000000)
        words+=str(ty)+" "+str(u)+" "+str(v)
        words+="\n"
f=open("input4.txt", "w+")
f.write(words)
f.close()
